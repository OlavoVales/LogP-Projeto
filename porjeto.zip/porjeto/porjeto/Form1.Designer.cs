﻿namespace porjeto
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtidade = new System.Windows.Forms.TextBox();
            this.lblidade = new System.Windows.Forms.Label();
            this.btnidade = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtidade
            // 
            this.txtidade.Location = new System.Drawing.Point(155, 139);
            this.txtidade.Name = "txtidade";
            this.txtidade.Size = new System.Drawing.Size(100, 20);
            this.txtidade.TabIndex = 0;
            this.txtidade.TextChanged += new System.EventHandler(this.txtidade_TextChanged);
            // 
            // lblidade
            // 
            this.lblidade.AutoSize = true;
            this.lblidade.Location = new System.Drawing.Point(182, 47);
            this.lblidade.Name = "lblidade";
            this.lblidade.Size = new System.Drawing.Size(33, 13);
            this.lblidade.TabIndex = 1;
            this.lblidade.Text = "idade";
            this.lblidade.Click += new System.EventHandler(this.label1_Click);
            // 
            // btnidade
            // 
            this.btnidade.Location = new System.Drawing.Point(140, 224);
            this.btnidade.Name = "btnidade";
            this.btnidade.Size = new System.Drawing.Size(115, 23);
            this.btnidade.TabIndex = 2;
            this.btnidade.Text = "mostre o resultado";
            this.btnidade.UseVisualStyleBackColor = true;
            this.btnidade.Click += new System.EventHandler(this.btnidade_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(441, 450);
            this.Controls.Add(this.btnidade);
            this.Controls.Add(this.lblidade);
            this.Controls.Add(this.txtidade);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtidade;
        private System.Windows.Forms.Label lblidade;
        private System.Windows.Forms.Button btnidade;
    }
}

