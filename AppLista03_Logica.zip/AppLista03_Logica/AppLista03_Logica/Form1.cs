﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista03_Logica
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void lbl2_Click(object sender, EventArgs e)
        {

        }

        private void btn_soma_Click(object sender, EventArgs e)
        {
            //Pegar os valores na tela

            float num1 = float.Parse(txt1.Text);
            float num2 = float.Parse(txt2.Text);
            float num3 = float.Parse(txt3.Text);
            float soma;

            //Calcular a soma

            soma = num1 + num2 + num3;

            //Mostrar o resultado

            MessageBox.Show("Soma = " + soma);   
        }

        private void btn_porcentagem_Click(object sender, EventArgs e)
        {

            //Pegar os valores na tela

            float num1 = float.Parse(txt1.Text);
            float num2 = float.Parse(txt2.Text);
            float num3 = float.Parse(txt3.Text);

            float porcentagem1;
            float porcentagem2;
            float porcentagem3;

            //calcular a porcentagem

            porcentagem =(num1 + num2 + num3) / 100

            //Mostrar o resultado

            MessageBox.Show("porcentagem = " + porcentagem);

        }

        private void btn_media_Click(object sender, EventArgs e)
        {

            //Pegar os valores na tela

            float num1 = float.Parse(txt1.Text);
            float num2 = float.Parse(txt2.Text);
            float num3 = float.Parse(txt3.Text);
            float media;

            //Calcular a média

            media = (num1 + num2 + num3) / 3;

            //Mostrar o resultado

            MessageBox.Show("Média = " + media);

        }
    }
}
