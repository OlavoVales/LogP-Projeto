﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace calculadora_teste
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int n1 = int.Parse(txt1.Text);
            int n2 = int.Parse(txt1.Text);
            float soma;
            soma = n1 + n2;
            MessageBox.Show("Soma igual a" + soma);
        }


        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            int n1 = int.Parse(txt1.Text);
            int n2 = int.Parse(txt1.Text);
            float divisao;
            divisao = n1 / n2;
            MessageBox.Show("Divisão igual a" + divisao);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int n1 = int.Parse(txt1.Text);
            int n2 = int.Parse(txt1.Text);
            float menos;
            menos = n1 - n2;
            MessageBox.Show("Divisão igual a" + menos);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int n1 = int.Parse(txt1.Text);
            int n2 = int.Parse(txt1.Text);
            float multiplicacao;
            multiplicacao = n1 * n2;
            MessageBox.Show("Multiplicação igual a" + multiplicacao);
        }
    }
}
